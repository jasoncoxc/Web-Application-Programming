﻿using Microsoft.AspNetCore.Mvc;
using PlanOfStudy.Models;
namespace PlanOfStudy.Controllers
{
    public class SavedPlanController : Controller
    {
        private ISavedPlanRepository repository;
        private Plan plan;
        public SavedPlanController(ISavedPlanRepository repoService, Plan planService)
        {
            repository = repoService;
            plan = planService;
        }
        public ViewResult Saveplan() => View(new SavedPlan());
        [HttpPost]
        public IActionResult Saveplan(SavedPlan savedPlan)
        {
            if (plan.Lines.Count() == 0)
            {
                ModelState.AddModelError("", "Sorry, your plan is empty!");
            }
            if (ModelState.IsValid)
            {
                savedPlan.Lines = plan.Lines.ToArray();
                repository.SaveSavedPlan(savedPlan);
                plan.Clear();
                return RedirectToPage("/Completed", new { PlanName = savedPlan.Name });
            }
            else
            {
                return View();
            }
        }
    }
}