using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PlanOfStudy.Pages
{
    public class _PlanLayoutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
