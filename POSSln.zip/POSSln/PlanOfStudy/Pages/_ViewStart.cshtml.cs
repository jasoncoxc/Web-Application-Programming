using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PlanOfStudy.Pages
{
    public class _ViewStartModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
