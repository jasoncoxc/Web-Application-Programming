﻿namespace PlanOfStudy.Models
{
    public class EFPOSRepository : IPOSRepository
    {
        private POSDbContext context;
        public EFPOSRepository(POSDbContext ctx)
        {
            context = ctx;
        }
        public IQueryable<Course> Courses => context.Courses;
        public void CreateCourse(Course c)
        {
            context.Add(c);
            context.SaveChanges();
        }
        public void DeleteCourse(Course c)
        {
            context.Remove(c);
            context.SaveChanges();
        }
        public void SaveCourse(Course c)
        {
            context.SaveChanges();
        }
    }
}
