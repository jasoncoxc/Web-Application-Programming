﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
namespace PlanOfStudy.Models
{
    public class Course
    {
        public long? CourseID { get; set; }
        [Required(ErrorMessage = "Please enter a course number")]
        [Column(TypeName = "varchar(50)")]        
        public string CourseNumber { get; set; } = String.Empty;
        [Required]
        [Range(1, double.MaxValue, ErrorMessage = "Please enter positive number of credits")]
        public int Credits { get; set; }
        [Required(ErrorMessage = "Please enter course description")]
        [Column(TypeName = "varchar(100)")]        
        public string Description { get; set; } = String.Empty;
    }
}