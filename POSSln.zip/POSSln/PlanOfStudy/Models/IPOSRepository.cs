﻿namespace PlanOfStudy.Models
{
    public interface IPOSRepository
    {
        IQueryable<Course> Courses { get; }
        void SaveCourse(Course c);
        void CreateCourse(Course c);
        void DeleteCourse(Course c);
    }
}