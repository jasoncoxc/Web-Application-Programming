﻿using Microsoft.EntityFrameworkCore;
namespace PlanOfStudy.Models
{
    public class EFSavedPlanRepository : ISavedPlanRepository
    {
        private POSDbContext context;
        public EFSavedPlanRepository(POSDbContext ctx)
        {
            context = ctx;
        }
        public IQueryable<SavedPlan> SavedPlans => context.SavedPlans
        .Include(sp => sp.Lines)
        .ThenInclude(l => l.Course);
        public void SaveSavedPlan(SavedPlan savedPlan)
        {
            context.AttachRange(savedPlan.Lines.Select(l => l.Course));
            if (savedPlan.SavedPlanID == 0)
            {
                context.SavedPlans.Add(savedPlan);
            }
            context.SaveChanges();
        }
    }
}