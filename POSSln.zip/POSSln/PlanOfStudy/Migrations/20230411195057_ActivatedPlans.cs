﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PlanOfStudy.Migrations
{
    public partial class ActivatedPlans : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "Activated",
                table: "SavedPlans",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Activated",
                table: "SavedPlans");
        }
    }
}
